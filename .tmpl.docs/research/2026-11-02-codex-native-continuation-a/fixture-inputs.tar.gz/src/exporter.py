from .options import BATCH_LIMIT, EXPORT_FORMAT

def export_records(records):
    return {"format": EXPORT_FORMAT, "items": records[:BATCH_LIMIT], "limit": BATCH_LIMIT}
