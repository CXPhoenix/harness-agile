# Cedar archive contract

Status: current. This is the authoritative behavior contract.

The exporter returns JSON. The maximum export batch is 25 records. Archives retain records for 14 days. See src/exporter.py, src/options.py and src/retention.py.
