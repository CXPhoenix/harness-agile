# Checksum proposal

Status: planned, not delivered. A future milestone may add SHA-256 checksums. This proposal does not specify current runtime behavior.
