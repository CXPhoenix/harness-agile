# Documentation authority

Status: current. ops/current.md and ops/interface.md define current behavior. ops/roadmap.md is planned and ops/history/2026-04.md is dated history. No tests or tickets certify delivery of the roadmap.
