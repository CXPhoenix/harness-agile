# Cedar archive interface

Status: current. export_records(records) returns a dict with format="json", items, and limit. Options are declared in src/options.py.
